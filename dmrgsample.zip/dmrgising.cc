#include "itensor/all.h"
#include <stdio.h>

using namespace itensor;

int main(int argc, char* argv[])
{
  if(argc != 4)
    {
      printfln("Usage: %s ArgvInputFile N hz",argv[0]);
      return 0;
    }
    //-----------//getting input parameters
    auto input = InputGroup(argv[1],"input");
    auto Jx = input.getReal("Jx",1.0); //coupling
    auto N = std::atoi(argv[2]);//chain length
    printfln("Got input.N = %d",N);
    auto hz = std::atof(argv[3]);//magnetic field strength
    printfln("Got input.hz = %.4f",hz);
    auto nsweeps = input.getInt("nsweeps"); //number of DMRG sweeps
    auto table = InputGroup(input,"sweeps");//parameters for each DMRG sweep
    auto quiet = input.getYesNo("quiet",true);//true for less DMRG running output
    //-------------//end of getting input parameters

    auto sweeps = Sweeps(nsweeps,table);//creat sweep object for DMRG
    println(sweeps);

    auto sites = SpinHalf(N);//define a spin-1/2 chain
    //------------//creat MPO object
    auto ampo = AutoMPO(sites);
    for(int j = 1; j < N; ++j)
        {
          ampo += Jx,"Sx",j,"Sx",j+1;
        }
    for(int j = 1; j <= N; ++j)
        {
          ampo += hz,"Sz",j;
        }
    auto H = MPO(ampo);
    //----------//end
    auto psi = MPS(sites);//define the wave function for the system
    auto energy = dmrg(psi,H,sweeps,{"Quiet",quiet});

    printfln("\nGround State Energy = %.10f",energy);
    printfln("\nUsing overlap = %.10f", overlap(psi,H,psi) );
    //overlap should be same as energy

return 0;
}
